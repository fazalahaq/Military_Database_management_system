 <html>
<body><br><br>
<link rel="stylesheet" type="text/css" href="style1.css">
<form>
<center>
<a href="sold_info.php"> <input type="button" id="button" value="Soldier Information Search"></a>&nbsp&nbsp&nbsp&nbsp
<a href="allsoldetails.php"> <input type="button" id="button" value="All soldier details"></a><br><br><br><br><br><br>
<a href="alld_details.php"> <input type="button" id="button" value="Department Information"></a>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
<a href="dept.php"> <input type="button" id="button" value="Department"></a><br><br><br><br><br><br><br>


<a href="weap_query.php"> <input type="button" id="button" value="Weapon Details"></a><br><br><br><br><br><br><br>
<a href="so.php"> <input type="button" id="button" value="Sting Operations"></a><br><br><br><br><br><br><br>
<a href="dlocation.php"> <input type="button" id="button" value="Department Location"></a><br><br><br><br><br><br><br><br>
<a href="dpd.php"> <input type="button" id="button" value="Dependant Information"></a><br><br><br><br><br><br><br><br>

<a href="index.php"><input type="button" id="button1" value="Log out"></a><br>
<!--<?php
session_unset(); 

// destroy the session 
session_destroy();
?>-->



</form>

</body>
</html>