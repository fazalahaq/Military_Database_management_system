<html>
<head>
<title>Corp detailed Information</title>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body background="images.jfif"><br><br><br><br>
<div id="main-wrapper">
<center><font color="black">
<b>Enter corp name to delete all his details</b></font><br><br><br><br>
<form action="sld_ddel.php" method="post">
<input class="inputvalues" type="text" placeholder="Corp name" name="name" required/><br><br><br>
<a href="xx.php">	<input type="submit" id="submit_btn" name="submit_btn"><br><br></a>
	</form>
	</center>
	</div>
</body>
</form>
</body>
</html>
