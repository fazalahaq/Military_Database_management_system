<html>
<head>
<title>Corp detailed Information</title>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body background="images.jfif"><br><br><br><br>
<div id="main-wrapper">
<center><font color="black">
<b>Enter corp name to view all details</b></font><br><br><br><br>
<form action="srch.php" method="post">
<input class="inputvalues" type="text" placeholder="Corp name" name="name" required/><br><br><br>
	<input type="submit" id="submit_btn" name="submit_btn"><br><br>
	</form>
	</center>
	</div>
</body>
</form>
</body>
</html>
