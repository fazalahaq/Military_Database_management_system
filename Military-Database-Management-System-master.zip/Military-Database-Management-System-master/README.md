# Military-Database-Management-System
This is a mini-project where all the details of the soldiers can be inserted and modified. 
Also this database contains the department,sting operations and dependent details.
Basically this project gives a view on how a database can be managed.
